# Load Libraries ----------------------------------------------------------
library(dplyr)
require(magick)
require(ggplot2)
require(ggimage)
library(ggforce)
library(janitor)
library(here)



# Read data and image -----------------------------------------------------
data <-  readxl::read_excel("docs/datos_planetas.xlsx")
colnames(data) <-
  c("planet",	"diameter",	"ring",	"num_moon",	"mass")
img = "docs/img/Planets.pdf"




# First plot --------------------------------------------------------------
data_plot <- data %>%
  mutate(
    planet_moon = case_when(
      ring == "TRUE"  & num_moon == 0 ~ "gaseous without moon",
      ring == "FALSE" & num_moon == 0 ~ "terrestrial without moon",
      ring == "TRUE"  & num_moon > 0 ~ "gaseous with moon",
      ring == "FALSE" & num_moon > 0 ~ "terrestrial with moon"
    )
  ) %>%
  group_by(planet_moon) %>%
  count() %>%
  rename(count_planet_moon = n)

p <- ggplot(data = data_plot,
            aes(x = factor(planet_moon),
                y = count_planet_moon)) +
  geom_col(fill = "white") +
  theme_classic() +
  scale_x_discrete(drop=FALSE) +
  scale_y_continuous(limit = c(0, 8), expand = c(0, 0)) +
  labs(y = "count", x = "") +
  theme(
    plot.title = element_text(color = "white", size = 14, face = "bold.italic"),
    axis.title.x = element_text(color = "white", size = 20, face = "bold"),
    axis.title.y = element_text(color = "white", size = 20, face = "bold"),
    axis.text.x = element_text(colour = 'white', size = 16),
    axis.text.y = element_text(colour = 'white', size = 16)
  ) +
  labs(y = "log(diameter)")
ggimage::ggbackground(p, img)



# Second plot -------------------------------------------------------------
data %>%
  ggplot(aes(y = log(diameter), x = log(mass))) +
  geom_point(
    fill = "blue",
    size = 3,
    color = "yellow",
    shape = 11
  ) +
  theme_dark() +
  geom_mark_circle(
    aes(filter =  planet == "Saturn", label = planet),
    col = "yellow",
    description = "Gaseous planet with 18 moons",
    label.fontsize = 14,
    expand = unit(1, 'mm'),
    con.cap = 0
  ) +
  geom_mark_circle(
    aes(filter =  planet == "Earth", label = planet),
    col = "yellow",
    description = "Terrestrial planet with 1 moon",
    label.fontsize = 14,
    expand = unit(1, 'mm'),
    con.cap = 0
  ) +
  theme(
    plot.title = element_text(color = "black", size = 14, face = "bold.italic"),
    axis.title.x = element_text(color = "black", size = 20, face = "bold"),
    axis.title.y = element_text(color = "black", size = 20, face = "bold"),
    axis.text.x = element_text(colour = 'black', size = 20),
    axis.text.y = element_text(colour = 'black', size = 20)
  )




# Third plot --------------------------------------------------------------
data %>%
  ggplot(aes(y = reorder(planet, mass), x = mass)) +
  geom_col(fill = "blue") +
  theme_classic() +
  labs(y = "planet") +
  theme(
    plot.title = element_text(color = "black", size = 14, face = "bold.italic"),
    axis.title.x = element_text(color = "black", size = 20, face = "bold"),
    axis.title.y = element_text(color = "black", size = 20, face = "bold"),
    axis.text.x = element_text(colour = 'black', size = 20),
    axis.text.y = element_text(colour = 'black', size = 20)
  ) +
  labs(x = "mass with respect the Earth", y = "planet")
